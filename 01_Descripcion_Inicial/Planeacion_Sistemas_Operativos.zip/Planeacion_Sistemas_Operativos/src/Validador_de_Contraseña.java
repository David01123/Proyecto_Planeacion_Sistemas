import java.util.Scanner;

public class Validador_de_Contraseña {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String password;
        boolean isValid;

        do {
            System.out.println("Ingrese una contraseña: ");
            password = scanner.nextLine();
            isValid = validatePassword(password);
            if (!isValid) {
                System.out.println("La contraseña no cumple con los requisitos. Por favor, intente de nuevo.");
            } else {
                System.out.println("¡Contraseña válida!");
            }
        } while (!isValid);
    }

    public static boolean validatePassword(String password) {
        if (password.length() < 8) {
            System.out.println("La contraseña debe tener al menos 8 caracteres.");
            return false;
        }
        if (!password.matches(".*[A-Z].*")) {
            System.out.println("La contraseña debe contener al menos una letra mayúscula.");
            return false;
        }
        if (!password.matches(".*[a-z].*")) {
            System.out.println("La contraseña debe contener al menos una letra minúscula.");
            return false;
        }
        if (!password.matches(".*\\d.*")) {
            System.out.println("La contraseña debe contener al menos un dígito.");
            return false;
        }
        if (!password.matches(".*[!@#\\$%\\^&\\*].*")) {
            System.out.println("La contraseña debe contener al menos un carácter especial (!, @, #, $, %, ^, &, *).");
            return false;
        }
        return true;
    }
}
