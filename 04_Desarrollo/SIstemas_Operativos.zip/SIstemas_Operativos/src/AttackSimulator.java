import java.util.Random;

public class AttackSimulator {

        private boolean isSystemBreached;

        public AttackSimulator() {
            isSystemBreached = false;
        }

        // Simula un ataque al sistema
        public void performAttack() {
            System.out.println("Simulando ataque al sistema...");

            // Aquí simulamos la posibilidad de éxito del ataque
            Random rand = new Random();
            int attackResult = rand.nextInt(100); // Probabilidad de éxito de ataque

            if (attackResult > 50) {
                isSystemBreached = true;
                System.out.println("Ataque exitoso: el sistema ha sido vulnerado.");
            } else {
                System.out.println("Ataque fallido: no se pudo vulnerar el sistema.");
            }
        }

        // Verifica si el sistema fue vulnerado
        public boolean isSystemBreached() {
            return isSystemBreached;
        }
    }


