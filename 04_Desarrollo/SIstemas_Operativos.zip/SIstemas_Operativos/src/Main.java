public class Main {

        public static void main(String[] args) {
            // Instancia del escáner de vulnerabilidades
            VulnerabilityScanner vulnerabilityScanner = new VulnerabilityScanner();
            vulnerabilityScanner.scanSystem();
            vulnerabilityScanner.showVulnerabilities();

            // Instancia del simulador de ataques
            AttackSimulator attackSimulator = new AttackSimulator();
            attackSimulator.performAttack();

            if (attackSimulator.isSystemBreached()) {
                System.out.println("El sistema fue comprometido. Revisar las vulnerabilidades.");
            } else {
                System.out.println("El sistema está seguro por ahora.");
            }
        }
}


